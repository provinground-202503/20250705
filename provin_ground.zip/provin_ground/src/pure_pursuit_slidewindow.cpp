#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <ackermann_msgs/AckermannDriveStamped.h>
#include <erp_driver/erpCmdMsg.h>
#include <tf/transform_datatypes.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <queue>
#include <algorithm> // std::min을 사용하기 위해 추가
#include <iomanip>

// 경로 상의 한 점을 나타내는 구조체
struct Waypoint {
    double x;
    double y;
    double yaw;
};

class PathTracker {
public:
    PathTracker() {
        // ROS 노드 핸들 생성
        ros::NodeHandle nh;
        ros::NodeHandle private_nh("~");

        // 파라미터 로드
        private_nh.param<std::string>("path_file", path_file_, "/root/erp42_ws/src/provin_ground/path/path_xyyaw.csv");
        private_nh.param<double>("lookahead_distance", ld_, 3.0); // 전방 주시 거리 (m)
        private_nh.param<double>("vehicle_speed", speed_, 1.5); // 차량 속도 (m/s)
        private_nh.param<double>("wheelbase", wheelbase_, 2.0); // 차량 축거 (m)

        // Subscriber 및 Publisher 설정
        pose_sub_ = nh.subscribe("/utm", 1, &PathTracker::poseCallback, this);
        // cmd_pub_ = nh.advertise<ackermann_msgs::AckermannDriveStamped>("/ackermann_cmd", 1);
        cmd_pub_ = nh.advertise<erp_driver::erpCmdMsg>("/erp42_ctrl_cmd",1);
        ack_pub_ = nh.advertise<ackermann_msgs::AckermannDriveStamped>("/ackermann_cmd",1);

        // 경로 파일 로드
        if (!loadPath()) {
            ros::shutdown();
        }

        // previous_x, previous_y 초기화
        previous_x = 0.0;
        previous_y = 0.0;
    }

private:
    // 콜백 함수: 현재 위치(/utm)를 수신했을 때 호출됨
    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        current_pose_ = *msg;
        
        // 첫 번째 콜백에서 previous 위치 초기화
        if (previous_x == 0.0 && previous_y == 0.0) {
            previous_x = current_pose_.pose.position.x;
            previous_y = current_pose_.pose.position.y;
        }

        trackPath();
    }

    // 경로 추종 로직
    void trackPath() {
        if (path_.empty()) return;

        // 가장 가까운 경로점 찾기
        int closest_idx = findClosestWaypoint();
        
        // 목표 지점(Lookahead point) 찾기 (슬라이딩 윈도우 적용)
        int target_idx = findLookaheadPoint(closest_idx);

        // 목표 지점까지의 각도(alpha) 계산
        double alpha = calculateAlpha(target_idx);

        // 조향각(Steering angle) 계산 (Pure Pursuit)
        double steering_angle = calculateSteeringAngle(alpha);

        // Ackermann command 메시지 생성 및 발행
        publishCommand(steering_angle);
    }

    // CSV 파일로부터 경로 로드
    bool loadPath() {
        std::ifstream file(path_file_);
        if (!file.is_open()) {
            ROS_ERROR("Cannot open path file: %s", path_file_.c_str());
            return false;
        }

        path_.clear();
        std::string line;
        // 헤더 라인 무시
        std::getline(file, line);

        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string value;
            Waypoint wp;
            
            // X, Y, Yaw 순서로 파싱
            std::getline(ss, value, ',');
            wp.x = std::stod(value);
            std::getline(ss, value, ',');
            wp.y = std::stod(value);
            std::getline(ss, value, ',');
            wp.yaw = std::stod(value);
            
            path_.push_back(wp);
        }
        file.close();
        ROS_INFO("Loaded %zu waypoints from %s", path_.size(), path_file_.c_str());
        return true;
    }

    // 현재 위치에서 가장 가까운 경로점 인덱스 반환
    int findClosestWaypoint() {
        int closest_idx = 0;
        double min_dist = std::numeric_limits<double>::max();

        for (int i = 0; i < path_.size(); ++i) {
            double dist = std::hypot(current_pose_.pose.position.x - path_[i].x,
                                     current_pose_.pose.position.y - path_[i].y);
            if (dist < min_dist) {
                min_dist = dist;
                closest_idx = i;
            }
        }
        return closest_idx;
    }

    // ⭐ [수정된 함수] 전방 주시 거리에 가장 가까운 목표 지점 인덱스 반환 (슬라이딩 윈도우 적용)
    int findLookaheadPoint(int start_idx) {
        // 슬라이딩 윈도우의 끝 인덱스를 계산합니다.
        // 현재 위치에서 가장 가까운 점(start_idx)으로부터 20개 뒤의 점을 윈도우의 끝으로 설정합니다.
        // 이때, 경로의 전체 크기를 넘어가지 않도록 std::min을 사용하여 안전장치를 마련합니다.
        int window_end_idx = std::min(start_idx + 20, (int)path_.size());

        // 윈도우 내(start_idx부터 window_end_idx 전까지)에서만 목표점을 탐색합니다.
        for (int i = start_idx; i < window_end_idx; ++i) {
            double dist = std::hypot(current_pose_.pose.position.x - path_[i].x,
                                     current_pose_.pose.position.y - path_[i].y);
            
            // 차량의 현재 위치로부터 거리가 전방 주시 거리(ld_)보다 멀어지는 첫 번째 점을 찾으면
            // 그 점의 인덱스를 목표점으로 반환합니다.
            if (dist >= ld_) {
                return i;
            }
        }

        // 만약 윈도우(20개) 내에서 전방 주시 거리보다 멀리 있는 점을 찾지 못했다면,
        // 윈도우의 가장 마지막 점을 목표점으로 반환합니다.
        // (window_end_idx는 포함되지 않는 인덱스이므로 -1을 해줍니다.)
        return window_end_idx - 1;
    }


    // 차량의 현재 Yaw 각도 반환
    double getCurrentYaw() {
        // Quaternion에서 Yaw를 직접 추출하는 방식이 더 안정적일 수 있습니다.
        // 현재 코드는 위치 변화량에 의존하므로 정지 상태나 저속에서 부정확할 수 있습니다.
        // 지금은 제공된 코드의 로직을 유지합니다.
        // tf::Quaternion q(
        //     current_pose_.pose.orientation.x,
        //     current_pose_.pose.orientation.y,
        //     current_pose_.pose.orientation.z,
        //     current_pose_.pose.orientation.w);
        // tf::Matrix3x3 m(q);
        // double roll, pitch, yaw;
        // m.getRPY(roll, pitch, yaw);
        
        // 만약 /utm 메시지의 orientation이 신뢰할 수 없다면 아래 로직을 사용합니다.
        double delta_x = current_pose_.pose.position.x - previous_x;
        double delta_y = current_pose_.pose.position.y - previous_y;
        // 이동 거리가 매우 작을 때는 이전 yaw 값을 사용하거나 0을 반환하여 불안정성을 줄일 수 있습니다.
        if (std::hypot(delta_x, delta_y) < 0.001) { // 10cm 미만 이동 시
            // 이전 yaw값을 저장해두고 사용하거나, 여기서는 간단히 0으로 처리 (개선 필요)
            // 실제로는 이전 yaw 값을 멤버 변수로 저장하고 사용하는 것이 좋습니다.
            return 0; 
        }
        double yaw = std::atan2(delta_y, delta_x);
        return yaw;
    }

    // 차량과 목표 지점 사이의 각도(alpha) 계산
    double calculateAlpha(int target_idx) {
        double target_x = path_[target_idx].x;
        double target_y = path_[target_idx].y;

        double current_x_pos = current_pose_.pose.position.x;
        double current_y_pos = current_pose_.pose.position.y;
        double current_yaw_val = getCurrentYaw();

        std::cout << std::fixed << std::setprecision(5); 
        std::cout<<"target x:"<<target_x<<", target y:"<<target_y<<std::endl;
        std::cout<<"current x:"<<current_x_pos<<", current y:"<<current_y_pos<<std::endl;
        double dx = target_x - current_x_pos;
        double dy = target_y - current_y_pos;
        std::cout<<"delta x: "<<dx<<", delta y: "<<dy<<std::endl;

        // 현재 위치 정보 업데이트
        previous_x = current_x_pos;
        previous_y = current_y_pos;

        std::cout<<"current_yaw_value: "<<current_yaw_val;
        
        double calculated_alpha = std::atan2(dy,dx)-current_yaw_val;
        std::cout<<" alpha: "<<calculated_alpha<<std::endl;

        // atan2(y,x) 순서에 유의
        return calculated_alpha;
    }
    
    // 조향각 계산 (Pure Pursuit 공식)
    double calculateSteeringAngle(double alpha) {
        double steeringangleCalculated=std::atan2(2.0 * wheelbase_ * std::sin(alpha), ld_);
        std::cout<<"steering: "<<steeringangleCalculated<<std::endl;
        return steeringangleCalculated;
    }

    // erpCmdMsg 발행
    void publishCommand(double steering_angle) {
        erp_driver::erpCmdMsg cmd_msg;
        cmd_msg.brake = 1; // 1: no brake
        cmd_msg.e_stop = false;
        cmd_msg.gear = 0; // 0: forward, 1: neutral, 2: rear
        cmd_msg.speed = speed_ * 36; // m/s to km/h * 10 (erp_driver 형식)

        double steering_angle_degree = steering_angle * 180.0 / M_PI;
        double steering_erp_short = steering_angle_degree * 71;
        if(steering_erp_short > 2000) steering_erp_short = 2000;
        if(steering_erp_short < -2000) steering_erp_short = -2000;
        cmd_msg.steer = static_cast<short>(steering_erp_short); // erp_driver 형식
        cmd_msg.steer *= -1; // mirroring
        std::cout<<"steering_degree: "<<steering_angle_degree<<std::endl;
        std::cout<<"steering_erp: "<<cmd_msg.steer<<std::endl;
        cmd_pub_.publish(cmd_msg);

        ackermann_msgs::AckermannDriveStamped ack_msg;
        ack_msg.header.stamp = ros::Time::now();
        ack_msg.header.frame_id = "base_link";
        ack_msg.drive.steering_angle = steering_angle; //mirroring
        ack_msg.drive.speed = speed_; 
        ack_pub_.publish(ack_msg);
    }

    // 멤버 변수
    ros::Subscriber pose_sub_;
    ros::Publisher cmd_pub_;
    ros::Publisher ack_pub_;
    geometry_msgs::PoseStamped current_pose_;
    std::vector<Waypoint> path_;
    std::string path_file_;

    // Pure Pursuit 파라미터
    double ld_; // lookahead_distance
    double speed_;
    double wheelbase_;

    // 이전 위치 저장을 위한 변수
    double previous_x, previous_y;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "path_tracker_node");
    PathTracker tracker;
    ros::spin();
    return 0;
}