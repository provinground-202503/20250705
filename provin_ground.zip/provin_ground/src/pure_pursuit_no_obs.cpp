#include <ros/ros.h> // ROS 기본 헤더
#include <geometry_msgs/Pose.h> // UTM 좌표를 위한 Pose 메시지
#include <sensor_msgs/Imu.h> // IMU 데이터를 위한 Imu 메시지
#include <erp_driver/erpCmdMsg.h> // ERP 차량 명령 메시지
#include <erp_driver/erpStatusMsg.h> // ERP 차량 상태 메시지

#include <cmath> // 수학 함수 (sqrt, atan2, sin 등)
#include <vector> // 동적 배열 (경로 데이터 저장)
#include <iostream> // 입출력 스트림
#include <fstream> // 파일 입출력 (CSV 읽기)
#include <sstream> // 문자열 스트림 (CSV 파싱)
#include <limits> // numeric_limits (최대값 초기화)

// 차량 제원 (ERP42 기준 예시 값)
const double WHEELBASE = 2.0; // 차량의 휠베이스 (m)
const double MAX_STEER_ANGLE_RAD = 28.0 * M_PI / 180.0; // 차량의 최대 조향각 (라디안)
const int MAX_ERP_STEER_VALUE = 2000; // ERP 드라이버가 인식하는 최대 조향 값 (0 ~ 2000)
// 조향각(라디안)을 ERP 조향 값으로 변환하는 계수 (예: 28도 -> 2000)
const double STEER_CONVERSION_FACTOR = MAX_ERP_STEER_VALUE / MAX_STEER_ANGLE_RAD;

// PID 제어 상수 (속도 제어용, 실제 차량에 맞게 튜닝 필요)
const double KP_VEL = 10.0; // 속도 비례 이득 (Proportional Gain)
const double KI_VEL = 0.5;  // 속도 적분 이득 (Integral Gain)
const double KD_VEL = 0.1;  // 속도 미분 이득 (Derivative Gain)

// Pure Pursuit 제어 상수 (조향 제어용, 실제 차량 및 환경에 맞게 튜닝 필요)
const double K_PURE_PURSUIT = 1.0; // Pure Pursuit gain (Look-ahead distance = K_PURE_PURSUIT * current_velocity)
const double MIN_LOOK_AHEAD_DIST = 2.0; // 최소 Look-ahead 거리 (m), 정지 또는 저속 시 사용
const double MAX_LOOK_AHEAD_DIST = 8.0; // 최대 Look-ahead 거리 (m), 고속 시 Look-ahead 거리 제한

// CSV 경로 파일의 각 지점 데이터를 저장하는 구조체
struct PathPoint {
    double x;        // X 좌표 (m)
    double y;        // Y 좌표 (m)
    double velocity; // 해당 지점에서의 목표 속도 (km/h)
    double yaw;      // 해당 지점에서의 목표 Yaw 각도 (라디안)
    double yaw_rate; // 해당 지점에서의 목표 Yaw Rate (라디안/초) - 현재 코드에서는 사용하지 않음
};

class PurePursuit{
public:
    // PurePursuit 클래스 생성자
    PurePursuit(){
        // ROS 노드 핸들 초기화 (이 노드의 이름은 "pg_pure_pursuit"로 설정됨)

        // ROS Subscriber 설정: 각 토픽에서 메시지를 받아 콜백 함수 호출
        // /utm 토픽 구독: 차량의 현재 UTM 좌표 (x, y)를 받음
        utm_sub = nh.subscribe("/utm", 10, &PurePursuit::utmCallBack, this);
        // /imu 토픽 구독: 차량의 현재 Yaw 각도를 받음 (Quaternion 형식)
        // imu_sub = nh.subscribe("/imu", 10, &PurePursuit::imuCallBack, this);
        // /erp_status 토픽 구독: 차량의 현재 속도 및 기타 상태를 받음
        erp_status_sub = nh.subscribe("/erp42_status", 10, &PurePursuit::erpStatusCallBack, this);

        // ROS Publisher 설정: 차량 제어 명령을 발행
        // /erp_cmd 토픽에 erp_driver::erpCmdMsg 메시지를 발행
        erp_cmd_pub = nh.advertise<erp_driver::erpCmdMsg>("/erp42_ctrl_cmd", 10);

        // 제어 주기 타이머 설정: 0.1초(100ms)마다 controlTimerCallBack 함수 호출
        control_timer = nh.createTimer(ros::Duration(0.1), &PurePursuit::controlTimerCallBack, this);

        // CSV 경로 파일 로드
        // "path/ctrack.csv" 파일을 읽어 경로 데이터를 path_data 벡터에 저장합니다.
        // 이 경로는 실제 CSV 파일의 위치에 맞게 수정해야 합니다.
        // 예시: "/home/user/catkin_ws/src/your_package_name/path/ctrack.csv"
        loadPath("/root/pg_ws/src/provin_ground/path/ctrack-example.csv"); // 실제 경로로 변경하세요!

        // 현재 차량 상태 변수 초기화
        previous_x = 0.0;
        previous_y = 0.0;
        current_x = 0.0;
        current_y = 0.0;
        current_yaw = 0.0;      // 라디안 단위
        current_velocity = 0.0; // km/h 단위

        // PID 제어 변수 초기화
        prev_error_vel = 0.0;       // 이전 속도 오차
        integral_error_vel = 0.0;   // 속도 오차의 누적 합 (적분 항)

        ROS_INFO("PurePursuit controller initialized.");
    }

    // UTM 좌표 콜백 함수
    // geometry_msgs::Pose 메시지에서 차량의 현재 X, Y 좌표를 업데이트합니다.
    void utmCallBack(const geometry_msgs::Pose::ConstPtr& msg){
        previous_x = current_x;
        previous_y = current_y;
        
        current_x = msg->position.x;
        current_y = msg->position.y;
        
        double delta_x = current_x - previous_x;
        double delta_y = current_y - previous_y;

        current_yaw = std::atan2(delta_y, delta_x);
        std::cout << "delta_X: " <<delta_x << ", delta_Y: " << delta_y << std::endl;
        // ROS_INFO_THROTTLE(1.0, "UTM 수신: x=%.2f, y=%.2f", current_x, current_y);
    }

    // IMU 콜백 함수
    // sensor_msgs::Imu 메시지에서 Quaternion 형태의 방향 데이터를 받아 Yaw 각도를 추출합니다.
    // 추출된 Yaw 각도는 라디안 단위로 current_yaw 변수에 저장됩니다.
    // void imuCallBack(const sensor_msgs::Imu::ConstPtr& msg){
    //     // Quaternion (x, y, z, w) to Euler (Yaw) 변환
    //     double qx = msg->orientation.x;
    //     double qy = msg->orientation.y;
    //     double qz = msg->orientation.z;
    //     double qw = msg->orientation.w;

    //     // Yaw (Z축 회전) 계산
    //     // 참고: https://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles
    //     double siny_cosp = 2 * (qw * qz + qx * qy);
    //     double cosy_cosp = 1 - 2 * (qy * qy + qz * qz);
    //     current_yaw = std::atan2(siny_cosp, cosy_cosp); // 결과는 라디안 단위
    //     // ROS_INFO_THROTTLE(1.0, "IMU Yaw 수신: %.2f rad (%.2f deg)", current_yaw, current_yaw * 180.0 / M_PI);
    // }

    // ERP Status 콜백 함수
    // erp_driver::erpStatusMsg 메시지에서 차량의 현재 속도를 업데이트합니다.
    // ERP Status 메시지의 speed 필드는 0.1 km/h 단위이므로 10으로 나누어 km/h로 변환합니다.
    void erpStatusCallBack(const erp_driver::erpStatusMsg::ConstPtr& msg){
        current_velocity = (double)msg->speed / 10.0; // 0.1km/h 단위를 km/h로 변환
        // ROS_INFO_THROTTLE(1.0, "ERP 속도 수신: %.2f km/h", current_velocity);
    }

    // 제어 타이머 콜백 함수 (메인 제어 로직이 구현되는 곳)
    // 0.1초마다 이 함수가 호출되어 차량의 속도 및 조향 명령을 계산하고 발행합니다.
    void controlTimerCallBack(const ros::TimerEvent& event){
        // 경로 데이터가 비어있으면 제어를 수행할 수 없음
        if (path_data.empty()) {
            ROS_WARN_THROTTLE(1.0, "empty path, cannot control the car.");
            return;
        }

        // 1. Look-ahead 거리 (Look-ahead Distance) 계산
        // 현재 차량 속도에 비례하여 Look-ahead 거리를 동적으로 조절합니다.
        // 이를 통해 저속에서는 정밀한 제어를, 고속에서는 안정적인 제어를 가능하게 합니다.
        double look_ahead_distance = K_PURE_PURSUIT * current_velocity;
        // 계산된 Look-ahead 거리가 최소/최대 값을 벗어나지 않도록 제한합니다.
        look_ahead_distance = std::max(MIN_LOOK_AHEAD_DIST, look_ahead_distance);
        look_ahead_distance = std::min(MAX_LOOK_AHEAD_DIST, look_ahead_distance);
        // ROS_INFO("계산된 Look-ahead 거리: %.2f m", look_ahead_distance);

        // 2. 경로에서 가장 가까운 지점 및 Look-ahead 지점 찾기
        size_t closest_point_idx = 0;
        double min_dist = std::numeric_limits<double>::max(); // 최소 거리를 무한대로 초기화

        // 현재 차량 위치에서 경로의 모든 지점까지의 거리를 계산하여 가장 가까운 지점을 찾습니다.
        for (size_t i = 0; i < path_data.size(); ++i) {
            double dx = path_data[i].x - current_x;
            double dy = path_data[i].y - current_y;
            double dist = std::sqrt(dx*dx + dy*dy); // 유클리드 거리 계산
            if (dist < min_dist) {
                min_dist = dist;
                closest_point_idx = i;
            }
        }
        // ROS_INFO("가장 가까운 경로 지점 인덱스: %zu, 거리: %.2f", closest_point_idx, min_dist);

        // Look-ahead 지점 찾기: 가장 가까운 지점부터 시작하여 Look-ahead 거리 이상 떨어진 지점을 찾습니다.
        PathPoint look_ahead_point;
        bool found_look_ahead = false;
        for (size_t i = closest_point_idx; i < path_data.size(); ++i) {
            double dx = path_data[i].x - current_x;
            double dy = path_data[i].y - current_y;
            double dist = std::sqrt(dx*dx + dy*dy);
            if (dist >= look_ahead_distance) {
                look_ahead_point = path_data[i]; // Look-ahead 지점 설정
                found_look_ahead = true;
                break;
            }
        }

        // 경로의 끝에 도달했거나 Look-ahead 지점을 찾지 못한 경우 (경로 끝 처리)
        // 이 경우, 경로의 마지막 지점을 Look-ahead 지점으로 사용합니다.
        if (!found_look_ahead) {
            look_ahead_point = path_data.back(); // 경로의 마지막 지점 사용
            ROS_WARN_THROTTLE(1.0, "cannot find lookahead point. using last point.");
        }
        // ROS_INFO("Look-ahead 지점: x=%.2f, y=%.2f, 목표 속도=%.2f km/h", look_ahead_point.x, look_ahead_point.y, look_ahead_point.velocity);

        // 3. Pure Pursuit 조향각 (Steering Angle) 계산
        // 차량의 현재 위치에서 Look-ahead 지점까지의 벡터와 차량의 현재 Yaw 각도 사이의 상대 각도 (alpha) 계산
        double alpha = std::atan2(look_ahead_point.y - current_y, look_ahead_point.x - current_x) - current_yaw;

        // 각도 정규화: alpha 값을 -PI ~ PI 범위로 조정하여 오차 계산의 정확성을 높입니다.
        while (alpha > M_PI) alpha -= 2 * M_PI;
        while (alpha < -M_PI) alpha += 2 * M_PI;

        // Pure Pursuit 공식 적용하여 목표 조향각 (라디안) 계산
        // delta = atan2(2 * L * sin(alpha), ld)
        // L: 휠베이스, alpha: 상대 각도, ld: Look-ahead 거리
        double target_steer_angle_rad = std::atan2(2 * WHEELBASE * std::sin(alpha), look_ahead_distance);

        // 조향각 제한: 계산된 조향각이 차량의 물리적인 최대 조향각을 넘지 않도록 제한합니다.
        target_steer_angle_rad = std::max(-MAX_STEER_ANGLE_RAD, target_steer_angle_rad);
        target_steer_angle_rad = std::min(MAX_STEER_ANGLE_RAD, target_steer_angle_rad);

        // ERP 조향 값으로 변환 (정수형)
        // ERP 드라이버는 -2000 (좌회전) ~ 2000 (우회전) 범위의 정수 값을 사용합니다.
        int32_t erp_steer_cmd = static_cast<int32_t>(target_steer_angle_rad * STEER_CONVERSION_FACTOR);
        // ROS_INFO("목표 조향각: %.2f rad (%.2f deg), ERP 조향 명령: %d", target_steer_angle_rad, target_steer_angle_rad * 180.0 / M_PI, erp_steer_cmd);

        // 4. 종방향 PID 속도 제어 (Longitudinal PID Velocity Control)
        double target_velocity_kmh = look_ahead_point.velocity; // Look-ahead 지점의 목표 속도 (km/h)
        double error_vel = target_velocity_kmh - current_velocity; // 현재 속도와 목표 속도 간의 오차

        // 비례 (P) 항 계산
        double proportional = KP_VEL * error_vel;

        // 적분 (I) 항 계산
        // 타이머 주기 (0.1초)를 곱하여 적분 값을 누적합니다.
        integral_error_vel += error_vel * 0.1;
        // 적분 항 제한 (Wind-up 현상 방지): 적분 값이 너무 커지는 것을 방지합니다.
        const double MAX_INTEGRAL_ERROR = 50.0; // 적분 항의 최대 허용 오차 (튜닝 필요)
        integral_error_vel = std::max(-MAX_INTEGRAL_ERROR, integral_error_vel);
        integral_error_vel = std::min(MAX_INTEGRAL_ERROR, integral_error_vel);
        double integral = KI_VEL * integral_error_vel;

        // 미분 (D) 항 계산
        // 이전 오차와의 차이를 타이머 주기(0.1초)로 나누어 미분 값을 계산합니다.
        double derivative = KD_VEL * (error_vel - prev_error_vel) / 0.1;
        prev_error_vel = error_vel; // 현재 오차를 다음 주기를 위해 저장

        // 최종 속도 명령 계산 (PID 제어 결과 합산)
        double command_velocity_kmh = proportional + integral + derivative;

        // 속도 명령 제한 (0 ~ 200, ERP 속도 단위)
        // ERP speed는 0.1km/h 단위이므로, km/h 값을 10배하여 ERP 드라이버에 맞는 값으로 변환합니다.
        command_velocity_kmh = std::max(0.0, command_velocity_kmh); // 최소 속도는 0
        command_velocity_kmh = std::min(20.0, command_velocity_kmh); // 최대 속도 20 km/h (안전을 위해 제한, 튜닝 가능)
        uint8_t erp_speed_cmd = static_cast<uint8_t>(command_velocity_kmh * 10.0); // 0.1 km/h 단위로 변환

        // ROS_INFO("목표 속도: %.2f km/h, 현재 속도: %.2f km/h, 계산된 명령 속도: %.2f km/h, ERP 속도 명령: %u",
        //          target_velocity_kmh, current_velocity, command_velocity_kmh, erp_speed_cmd);

        // 5. ERP Cmd 메시지 발행
        erp_driver::erpCmdMsg erp_cmd_msg;
        erp_cmd_msg.e_stop = false;   // 비상 정지 해제 (true로 설정 시 차량 정지)
        erp_cmd_msg.gear = 0;         // 0: 전진 (Forward), 1: 후진 (Backward), 2: 중립 (Neutral)
        erp_cmd_msg.speed = erp_speed_cmd; // 계산된 속도 명령 (0.1 km/h 단위)
        erp_cmd_msg.steer = erp_steer_cmd; // 계산된 조향 명령 (-2000 ~ 2000)
        erp_cmd_msg.brake = 0;        // 브레이크 값 (0-200, 필요시 조절)

        erp_cmd_pub.publish(erp_cmd_msg); // ERP 명령 메시지 발행
    }

private:
    ros::NodeHandle nh; // ROS 노드 핸들

    // ROS Subscriber 객체들
    ros::Subscriber utm_sub; // UTM 좌표 구독자
    ros::Subscriber imu_sub; // IMU 데이터 구독자
    ros::Subscriber erp_status_sub; // ERP 상태 구독자

    // ROS Publisher 객체
    ros::Publisher erp_cmd_pub; // ERP 명령 발행자

    // ROS Timer 객체
    ros::Timer control_timer; // 제어 주기 타이머

    // 차량의 현재 상태를 저장하는 변수들
    double previous_x;
    double previous_y;
    double current_x;        // 현재 X 좌표 (m)
    double current_y;        // 현재 Y 좌표 (m)
    double current_yaw;      // 현재 Yaw 각도 (라디안)
    double current_velocity; // 현재 속도 (km/h)

    // CSV 파일에서 로드된 경로 데이터를 저장하는 벡터
    std::vector<PathPoint> path_data;

    // PID 제어에 사용되는 변수들
    double prev_error_vel;       // 이전 속도 오차
    double integral_error_vel;   // 속도 오차의 적분 값

    // CSV 파일에서 경로 데이터를 로드하는 함수
    // 파일 경로를 인자로 받아 해당 파일에서 x, y, velocity, yaw, yaw_rate 데이터를 읽어옵니다.
    void loadPath(const std::string& filename) {
        std::ifstream file(filename); // 파일 스트림 열기
        if (!file.is_open()) { // 파일 열기 실패 시
            ROS_ERROR("cannot open file: %s", filename.c_str());
            return;
        }

        std::string line;
        // CSV 파일의 첫 번째 줄 (헤더) 건너뛰기
        std::getline(file, line);

        // 파일의 각 줄을 읽어 PathPoint 구조체에 파싱하여 path_data 벡터에 저장
        while (std::getline(file, line)) {
            std::stringstream ss(line); // 줄을 문자열 스트림으로 변환
            std::string segment;
            PathPoint point;
            std::vector<double> values;

            // 콤마(,)로 구분된 각 값을 파싱하여 values 벡터에 저장
            while(std::getline(ss, segment, ',')) {
                try {
                    values.push_back(std::stod(segment)); // 문자열을 double로 변환
                } catch (const std::invalid_argument& e) {
                    ROS_ERROR("invalid number: %s (line: %s)", segment.c_str(), line.c_str());
                    values.clear(); // 잘못된 데이터이므로 현재 줄의 파싱 중단
                    break;
                } catch (const std::out_of_range& e) {
                    ROS_ERROR("out of range: %s (line: %s)", segment.c_str(), line.c_str());
                    values.clear(); // 잘못된 데이터이므로 현재 줄의 파싱 중단
                    break;
                }
            }

            // 파싱된 값이 PathPoint 구조체에 필요한 최소 개수(5개: x, y, velocity, yaw, yaw_rate)인지 확인
            if (values.size() >= 5) {
                point.x = values[0];
                point.y = values[1];
                point.velocity = values[2];
                point.yaw = values[3];
                point.yaw_rate = values[4];
                path_data.push_back(point); // 파싱된 PathPoint를 벡터에 추가
            } else if (!values.empty()) { // 파싱은 되었으나 개수가 부족한 경우
                ROS_WARN("jump invalid line(need row: 5개, found row: %zu): %s", values.size(), line.c_str());
            }
        }
        ROS_INFO("%s file, %zu path points loaded.", filename.c_str(), path_data.size());
        file.close(); // 파일 스트림 닫기
    }
};

// 메인 함수
int main(int argc,char** argv){
    // ROS 시스템 초기화 및 노드 이름 설정
    ros::init(argc,argv,"pg_pure_pursuit");
    // PurePursuit 클래스의 인스턴스 생성 (생성자 호출로 초기화 및 ROS 설정 완료)
    PurePursuit pp;
    // ROS 이벤트 루프 시작: 모든 콜백 함수들이 호출되도록 대기합니다.
    ros::spin();
    return 0;
}
