#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
// #include <ackermann_msgs/AckermannDriveStamped.h>
#include <erp_driver/erpCmdMsg.h>
#include <tf/transform_datatypes.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <queue>

// 경로 상의 한 점을 나타내는 구조체
struct Waypoint {
    double x;
    double y;
    double yaw;
};

class PathTracker {
public:
    PathTracker() {
        // ROS 노드 핸들 생성
        ros::NodeHandle nh;
        ros::NodeHandle private_nh("~");

        // 파라미터 로드
        private_nh.param<std::string>("path_file", path_file_, "/root/erp42_ws/src/provin_ground/path/path_xyyaw.csv");
        private_nh.param<double>("lookahead_distance", ld_, 3.0); // 전방 주시 거리 (m)
        private_nh.param<double>("vehicle_speed", speed_, 1.5); // 차량 속도 (m/s)
        private_nh.param<double>("wheelbase", wheelbase_, 2.0); // 차량 축거 (m)

        // Subscriber 및 Publisher 설정
        pose_sub_ = nh.subscribe("/utm", 1, &PathTracker::poseCallback, this);
        // cmd_pub_ = nh.advertise<ackermann_msgs::AckermannDriveStamped>("/ackermann_cmd", 1);
        cmd_pub_ = nh.advertise<erp_driver::erpCmdMsg>("/erp42_ctrl_cmd",1);

        // 경로 파일 로드
        if (!loadPath()) {
            ros::shutdown();
        }
    }

private:
    // 콜백 함수: 현재 위치(/utm)를 수신했을 때 호출됨
    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        current_pose_ = *msg;
        trackPath();
    }

    // 경로 추종 로직
    void trackPath() {
        if (path_.empty()) return;

        // 가장 가까운 경로점 찾기
        int closest_idx = findClosestWaypoint();
        
        // 목표 지점(Lookahead point) 찾기
        int target_idx = findLookaheadPoint(closest_idx);

        // 목표 지점까지의 각도(alpha) 계산
        double alpha = calculateAlpha(target_idx);

        // 조향각(Steering angle) 계산 (Pure Pursuit)
        double steering_angle = calculateSteeringAngle(alpha);

        // Ackermann command 메시지 생성 및 발행
        publishCommand(steering_angle);
    }

    // CSV 파일로부터 경로 로드
    bool loadPath() {
        std::ifstream file(path_file_);
        if (!file.is_open()) {
            ROS_ERROR("Cannot open path file: %s", path_file_.c_str());
            return false;
        }

        path_.clear();
        std::string line;
        // 헤더 라인 무시
        std::getline(file, line);

        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string value;
            Waypoint wp;
            
            // X, Y, Yaw 순서로 파싱
            std::getline(ss, value, ',');
            wp.x = std::stod(value);
            std::getline(ss, value, ',');
            wp.y = std::stod(value);
            std::getline(ss, value, ',');
            wp.yaw = std::stod(value);
            
            path_.push_back(wp);
        }
        file.close();
        ROS_INFO("Loaded %zu waypoints from %s", path_.size(), path_file_.c_str());
        return true;
    }

    // 현재 위치에서 가장 가까운 경로점 인덱스 반환
    int findClosestWaypoint() {
        int closest_idx = 0;
        double min_dist = std::numeric_limits<double>::max();

        for (int i = 0; i < path_.size(); ++i) {
            double dist = std::hypot(current_pose_.pose.position.x - path_[i].x,
                                     current_pose_.pose.position.y - path_[i].y);
            if (dist < min_dist) {
                min_dist = dist;
                closest_idx = i;
            }
        }
        return closest_idx;
    }

    // 전방 주시 거리에 가장 가까운 목표 지점 인덱스 반환
    int findLookaheadPoint(int start_idx) {
        int target_idx = start_idx;
        for (int i = start_idx; i < path_.size(); ++i) {
            double dist = std::hypot(current_pose_.pose.position.x - path_[i].x,
                                     current_pose_.pose.position.y - path_[i].y);
            if (dist >= ld_) {
                return i;
            }
            target_idx = i;
        }
        return target_idx; // 경로의 마지막 점
    }

    // 차량의 현재 Yaw 각도 반환 (Quaternion -> Euler)
    double getCurrentYaw() {
        // tf::Quaternion q(
        //     current_pose_.pose.orientation.x,
        //     current_pose_.pose.orientation.y,
        //     current_pose_.pose.orientation.z,
        //     current_pose_.pose.orientation.w);
        // tf::Matrix3x3 m(q);
        // double roll, pitch, yaw;
        // m.getRPY(roll, pitch, yaw);
        double delta_x = current_pose_.pose.position.x - previous_x;
        double delta_y = current_pose_.pose.position.y - previous_y;
        double yaw = std::atan2(delta_x,delta_y);
        return yaw;
    }

    // 차량과 목표 지점 사이의 각도(alpha) 계산
    double calculateAlpha(int target_idx) {
        double target_x = path_[target_idx].x;
        double target_y = path_[target_idx].y;

        double current_yaw = getCurrentYaw();
        previous_x = current_pose_.pose.position.x;
        previous_y = current_pose_.pose.position.y;

        double dx = target_x - previous_x;
        double dy = target_y - previous_y;

        return std::atan2(dy, dx) - current_yaw;
    }
    
    // 조향각 계산 (Pure Pursuit 공식)
    double calculateSteeringAngle(double alpha) {
        return std::atan2(2.0 * wheelbase_ * std::sin(alpha), ld_);
    }

    // Ackermann command 발행
    void publishCommand(double steering_angle) {
        // ackermann_msgs::AckermannDriveStamped cmd_msg;
        // cmd_msg.header.stamp = ros::Time::now();
        // cmd_msg.header.frame_id = "base_link"; // 또는 차량의 base frame
        // cmd_msg.drive.steering_angle = steering_angle;
        // cmd_msg.drive.speed = speed_;

        erp_driver::erpCmdMsg cmd_msg;
        cmd_msg.brake = 1; // 1~200 1:no brake
        cmd_msg.e_stop=false;
        cmd_msg.gear= 0; //0 forward 1 neutral 2 rear
        cmd_msg.speed = speed_ * 3600/1000 * 10;
        /*
        speed_ = m/s
        speed  = km/h
        speed *= speed_ * 3600 / 1000 * 10
        */
        double steering_angle_degree = steering_angle * 180 / M_PI;
        cmd_msg.steer = steering_angle_degree * 71;
        /*
        steering_angle (radian)
        steering_angle_degree = steering_angle * 180 / M_PI
        steer: -2000~+2000
        steer = steering_angle_degree * 71

        */

        cmd_pub_.publish(cmd_msg);
    }

    // 멤버 변수
    ros::Subscriber pose_sub_;
    ros::Publisher cmd_pub_;
    geometry_msgs::PoseStamped current_pose_;
    std::vector<Waypoint> path_;
    std::queue<Waypoint> sliding_path_;
    std::string path_file_;

    // Pure Pursuit 파라미터
    double ld_; // lookahead_distance
    double speed_;
    double wheelbase_;

    double current_x, current_y;
    double previous_x, previous_y;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "path_tracker_node");
    PathTracker tracker;
    ros::spin();
    return 0;
}